package com.aetheros.store;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * APK indirme + otomatik kurulum eklentisi.
 *
 * - Indirme Android DownloadManager ile yapilir: sistem bildirim cubugunda (ust menu / kontrol merkezi)
 *   canli ilerleme cubugu gosterilir.
 * - Ilerleme 400 ms'de bir "downloadProgress" olayi ile web arayuzune iletilir.
 * - Indirme %100 oldugunda paket yukleyici (ACTION_VIEW + application/vnd.android.package-archive) otomatik acilir.
 * - REQUEST_INSTALL_PACKAGES izni AndroidManifest'te tanimlidir; "bilinmeyen kaynaklardan yukleme"
 *   ayari canInstall() ile sorgulanir, openInstallSettings() ile ayar ekrani acilir.
 */
@CapacitorPlugin(name = "ApkInstaller")
public class ApkInstallerPlugin extends Plugin {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<Long, File> files = new HashMap<>();

    @PluginMethod
    public void canInstall(PluginCall call) {
        boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || getContext().getPackageManager().canRequestPackageInstalls();
        JSObject ret = new JSObject();
        ret.put("granted", granted);
        call.resolve(ret);
    }

    @PluginMethod
    public void openInstallSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        }
        call.resolve();
    }

    @PluginMethod
    public void download(PluginCall call) {
        String url = call.getString("url");
        String fileName = call.getString("fileName", "app.apk");
        String title = call.getString("title", fileName);
        if (url == null) {
            call.reject("url gerekli");
            return;
        }
        try {
            Context ctx = getContext();
            File dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            File target = new File(dir, fileName);
            if (target.exists()) //noinspection ResultOfMethodCallIgnored
                target.delete();

            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setTitle(title);
            req.setDescription("AetherOS");
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, fileName);

            DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
            final long id = dm.enqueue(req);
            files.put(id, target);

            JSObject ret = new JSObject();
            ret.put("downloadId", id);
            call.resolve(ret);

            poll(dm, id);
        } catch (Exception e) {
            call.reject("Indirme baslatilamadi: " + e.getMessage());
        }
    }

    @PluginMethod
    public void install(PluginCall call) {
        String fileName = call.getString("fileName");
        if (fileName == null) {
            call.reject("fileName gerekli");
            return;
        }
        File f = new File(getContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName);
        launchInstaller(f);
        call.resolve();
    }

    private void poll(final DownloadManager dm, final long id) {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Cursor c = dm.query(new DownloadManager.Query().setFilterById(id));
                if (c == null) return;
                try {
                    if (!c.moveToFirst()) return; // iptal edilmis
                    int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    long got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    long total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));

                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        emit("downloadProgress", id, 100, got, total);
                        emit("downloadComplete", id, 100, got, total);
                        File f = files.remove(id);
                        if (f != null) launchInstaller(f);
                        emit("installLaunched", id, 100, got, total);
                        return;
                    }
                    if (status == DownloadManager.STATUS_FAILED) {
                        JSObject o = new JSObject();
                        o.put("downloadId", id);
                        o.put("reason", "Indirme basarisiz (kod " +
                                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)) + ")");
                        notifyListeners("downloadFailed", o);
                        files.remove(id);
                        return;
                    }
                    int pct = total > 0 ? (int) Math.min(99, Math.max(1, got * 100 / total)) : 1;
                    emit("downloadProgress", id, pct, got, total);
                } finally {
                    c.close();
                }
                handler.postDelayed(this, 400);
            }
        }, 400);
    }

    private void emit(String event, long id, int pct, long got, long total) {
        JSObject o = new JSObject();
        o.put("downloadId", id);
        o.put("progress", pct);
        o.put("received", got);
        o.put("total", total);
        notifyListeners(event, o);
    }

    /** Paket yukleyiciyi dogrudan acar. Izin yoksa once ayar ekranina gider. */
    private void launchInstaller(File apk) {
        Context ctx = getContext();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !ctx.getPackageManager().canRequestPackageInstalls()) {
            Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + ctx.getPackageName()));
            s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(s);
            return;
        }
        Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", apk);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }
}
