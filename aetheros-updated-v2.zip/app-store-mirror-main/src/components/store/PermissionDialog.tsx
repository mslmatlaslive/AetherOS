import { PackageCheck } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { useInstall } from "@/lib/install";

/** REQUEST_INSTALL_PACKAGES için bir defaya mahsus izin penceresi. */
export function PermissionDialog() {
  const { permissionOpen, answerPermission } = useInstall();
  return (
    <Dialog open={permissionOpen} onOpenChange={(o) => !o && answerPermission(false)}>
      <DialogContent className="w-[calc(100%-2rem)] max-w-[360px] gap-0 rounded-[28px] border-0 p-6 text-center shadow-2xl sm:rounded-[28px]">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22%] bg-secondary text-primary">
          <PackageCheck className="h-8 w-8" />
        </div>
        <DialogTitle className="mt-4 text-[22px] font-bold">Paket Yükleme İzni</DialogTitle>
        <DialogDescription className="mt-2 text-[15px] leading-snug">
          AetherOS'un indirdiğiniz uygulamaları (.apk) doğrudan kurabilmesi için bu izne ihtiyacı var. İzin yalnızca bir
          kez istenir; sonraki indirmelerde tekrar sorulmaz.
        </DialogDescription>
        <button
          onClick={() => answerPermission(true)}
          className="mt-5 w-full rounded-xl bg-primary py-3 text-[17px] font-semibold text-primary-foreground"
        >
          İzin Ver
        </button>
        <button onClick={() => answerPermission(false)} className="mt-2 w-full py-2 text-[16px] text-primary">
          Şimdi Değil
        </button>
      </DialogContent>
    </Dialog>
  );
}
