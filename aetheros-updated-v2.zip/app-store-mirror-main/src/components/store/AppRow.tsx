import { Link } from "@tanstack/react-router";
import { Check, Loader2 } from "lucide-react";
import type { AppSummary } from "@/lib/store.functions";
import { useAuth } from "@/lib/auth";
import { isActive, useDownload } from "@/lib/downloads";
import { useInstall } from "@/lib/install";
import { DownloadBar, ProgressRing } from "./DownloadProgress";
import { Stars } from "./Stars";

export function AppIcon({ src, size = 64 }: { src: string; size?: number }) {
  return (
    <img
      src={src}
      alt=""
      loading="lazy"
      decoding="async"
      width={size}
      height={size}
      className="shrink-0 rounded-[22%] border border-border bg-muted object-cover"
      style={{ width: size, height: size }}
    />
  );
}

type Target = Pick<AppSummary, "id" | "name" | "icon" | "apk" | "size">;

export function GetButton({
  app,
  label = "YÜKLE",
  big,
  overlay,
}: {
  app: Target;
  label?: string;
  big?: boolean;
  overlay?: boolean;
}) {
  const { install } = useInstall();
  const d = useDownload(app.id);

  const cls = big
    ? "inline-flex min-w-[80px] justify-center rounded-full bg-primary px-5 py-1.5 text-[15px] font-bold text-primary-foreground"
    : overlay
      ? "inline-flex min-w-[80px] shrink-0 items-center justify-center rounded-full bg-white/25 px-4 py-1.5 text-[15px] font-bold text-white backdrop-blur"
      : "inline-flex min-w-[72px] shrink-0 items-center justify-center rounded-full bg-secondary px-4 py-1.5 text-sm font-bold text-primary";

  if (!app.apk) return <span className={`${cls} opacity-50`}>YOK</span>;

  if (isActive(d)) {
    return (
      <span
        className={`inline-flex min-w-[72px] shrink-0 items-center justify-center gap-1 ${overlay ? "text-white" : "text-primary"}`}
        aria-label={`İndiriliyor %${d!.progress}`}
      >
        {d!.status === "installing" ? <Loader2 className="h-6 w-6 animate-spin" /> : <ProgressRing value={d!.progress} size={30} />}
      </span>
    );
  }

  if (d?.status === "done") {
    return (
      <span className={`${cls} gap-1`}>
        <Check className="h-4 w-4" /> Tamam
      </span>
    );
  }

  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        install(app);
      }}
      className={cls}
    >
      {d?.status === "error" ? "TEKRAR" : label}
    </button>
  );
}

export function AppRow({ app, rank }: { app: AppSummary; rank?: number }) {
  const { user, openAuth } = useAuth();
  return (
    <div className="flex items-center gap-3 py-3">
      <Link
        to="/app/$id"
        params={{ id: app.id }}
        onClick={(e) => {
          // Giriş yapmayan kullanıcı içeriğe erişemez: giriş penceresi açılır.
          if (!user) {
            e.preventDefault();
            openAuth({ reason: "Uygulama sayfalarını görmek için Proton Mail hesabınızla oturum açın." });
          }
        }}
        className="flex min-w-0 flex-1 items-center gap-3"
      >
        <AppIcon src={app.icon} />
        {rank !== undefined && <span className="w-6 text-center text-base font-semibold">{rank}</span>}
        <div className="min-w-0 flex-1 border-b border-border pb-3">
          <p className="truncate text-[15px] font-medium">{app.name}</p>
          <p className="truncate text-[13px] text-muted-foreground">{app.developer}</p>
          <div className="mt-0.5 flex items-center gap-1 text-[11px] text-muted-foreground">
            {app.rating ? <Stars value={app.rating} size={10} /> : null}
            {app.downloads ? <span>{formatCount(app.downloads)} indirme</span> : null}
          </div>
          <DownloadBar id={app.id} className="mt-1.5" />
        </div>
      </Link>
      <GetButton app={app} />
    </div>
  );
}

export function formatCount(n: number) {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1).replace(".0", "")} Mr`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace(".0", "")} Mn`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1).replace(".0", "")} B`;
  return String(n);
}
