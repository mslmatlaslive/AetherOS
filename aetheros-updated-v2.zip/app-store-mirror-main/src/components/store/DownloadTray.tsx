import { CheckCircle2, Download, TriangleAlert } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetTitle } from "@/components/ui/sheet";
import { clearFinished, isActive, setPanelOpen, useDownloads, usePanelOpen } from "@/lib/downloads";

/** Üst bildirim "hapı" + AetherOS indirme paneli (kontrol merkezi). */
export function DownloadTray() {
  const items = useDownloads();
  const open = usePanelOpen();
  const active = items.filter(isActive);
  const lead = active[0];
  const avg = active.length ? Math.round(active.reduce((s, d) => s + d.progress, 0) / active.length) : 0;

  return (
    <>
      {lead && (
        <div className="pointer-events-none fixed inset-x-0 top-0 z-[46] pt-[calc(env(safe-area-inset-top)+8px)]">
          <div className="mx-auto flex max-w-2xl justify-center px-[64px]">
            <button
              onClick={() => setPanelOpen(true)}
              className="pointer-events-auto w-full max-w-[300px] rounded-full bg-black/85 px-3 py-1.5 text-left text-white shadow-lg backdrop-blur-xl"
            >
              <div className="flex items-center gap-2">
                <Download className="h-3.5 w-3.5 shrink-0" />
                <span className="min-w-0 flex-1 truncate text-[12px] font-semibold">
                  {active.length > 1 ? `${active.length} indirme` : lead.name}
                </span>
                <span className="text-[12px] font-bold tabular-nums">%{avg}</span>
              </div>
              <div className="mt-1 h-[3px] overflow-hidden rounded-full bg-white/25">
                <div className="h-full rounded-full bg-white transition-[width] duration-200" style={{ width: `${avg}%` }} />
              </div>
            </button>
          </div>
        </div>
      )}

      <Sheet open={open} onOpenChange={setPanelOpen}>
        <SheetContent side="top" className="mx-auto max-w-2xl rounded-b-[28px] border-0 bg-background/95 pt-[calc(env(safe-area-inset-top)+20px)] backdrop-blur-2xl">
          <SheetTitle className="text-[13px] font-semibold uppercase tracking-wide text-muted-foreground">AetherOS</SheetTitle>
          <SheetDescription className="text-[26px] font-extrabold leading-tight text-foreground">İndirmeler</SheetDescription>

          {items.length === 0 && <p className="py-8 text-center text-muted-foreground">Devam eden indirme yok.</p>}

          <div className="mt-4 space-y-3">
            {items.map((d) => (
              <div key={d.id} className="rounded-2xl bg-muted p-3">
                <div className="flex items-center gap-3">
                  <img src={d.icon} alt="" width={44} height={44} className="h-11 w-11 shrink-0 rounded-[22%] border border-border object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[15px] font-semibold">{d.name}</p>
                    <p className="truncate text-[12px] text-muted-foreground">
                      {d.status === "downloading" && `İndiriliyor… ${fmt(d.received)}${d.total ? ` / ${fmt(d.total)}` : ""}`}
                      {d.status === "installing" && (d.note ?? "Yükleniyor…")}
                      {d.status === "done" && (d.note ?? "Tamamlandı")}
                      {d.status === "error" && (d.note ?? "Hata")}
                    </p>
                  </div>
                  {d.status === "done" && <CheckCircle2 className="h-5 w-5 text-green-600" />}
                  {d.status === "error" && <TriangleAlert className="h-5 w-5 text-destructive" />}
                  {isActive(d) && <span className="text-[13px] font-bold tabular-nums">%{d.progress}</span>}
                </div>
                {isActive(d) && (
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-black/10 dark:bg-white/15">
                    <div className="h-full rounded-full bg-primary transition-[width] duration-200" style={{ width: `${d.progress}%` }} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {items.some((d) => !isActive(d)) && (
            <button onClick={clearFinished} className="mt-4 w-full py-2 text-[15px] text-primary">
              Tamamlananları Temizle
            </button>
          )}
        </SheetContent>
      </Sheet>
    </>
  );
}

function fmt(b: number) {
  if (!b) return "0 MB";
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}
