import { useEffect, useState, type FormEvent } from "react";
import { Eye, EyeOff, Loader2, LogOut, Mail, ShieldCheck, User as UserIcon } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { PROTON_ERROR, PROTON_RE, useAuth } from "@/lib/auth";
import { clearFinished, setPanelOpen, useDownloads } from "@/lib/downloads";

export function AuthDialog() {
  const { user, dialogOpen, closeAuth, reason, signIn, signUp, signOut } = useAuth();
  const downloads = useDownloads();

  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!dialogOpen) {
      setError(null);
      setPassword("");
      setBusy(false);
    }
  }, [dialogOpen]);

  const trimmed = email.trim();
  const domainPart = trimmed.split("@")[1];
  const domainBad = !!domainPart && !PROTON_RE.test(trimmed);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!PROTON_RE.test(trimmed)) {
      setError(PROTON_ERROR);
      return;
    }
    setBusy(true);
    try {
      const err = mode === "in" ? await signIn(trimmed, password) : await signUp(name, trimmed, password);
      if (err) setError(err);
    } catch {
      setError("Bir sorun oluştu. Lütfen tekrar deneyin.");
    } finally {
      setBusy(false);
    }
  }

  const row = "flex items-center gap-3 px-4 py-3";
  const input = "w-full bg-transparent text-[17px] outline-none placeholder:text-muted-foreground";

  return (
    <Dialog open={dialogOpen} onOpenChange={(o) => !o && closeAuth()}>
      <DialogContent className="max-h-[92vh] w-[calc(100%-2rem)] max-w-[390px] gap-0 overflow-y-auto rounded-[28px] border-0 p-0 shadow-2xl sm:rounded-[28px]">
        {user ? (
          <div className="px-6 pb-6 pt-8 text-center">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-primary via-chart-2 to-chart-4 text-[34px] font-semibold text-white">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <DialogTitle className="mt-4 text-[22px]">{user.name}</DialogTitle>
            <DialogDescription className="mt-1 text-[15px]">{user.email}</DialogDescription>

            <div className="mt-6 overflow-hidden rounded-2xl bg-muted text-left">
              <button
                onClick={() => {
                  closeAuth();
                  setPanelOpen(true);
                }}
                className={`${row} w-full justify-between border-b border-border`}
              >
                <span className="text-[16px]">İndirmeler</span>
                <span className="text-[15px] text-muted-foreground">{downloads.length}</span>
              </button>
              <button
                onClick={() => {
                  clearFinished();
                  signOut();
                }}
                className={`${row} w-full text-destructive`}
              >
                <LogOut className="h-5 w-5" />
                <span className="text-[16px] font-medium">Oturumu Kapat</span>
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="px-6 pb-6 pt-8">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22%] bg-gradient-to-br from-primary via-chart-2 to-chart-4 text-white shadow-lg">
              <ShieldCheck className="h-8 w-8" />
            </div>
            <DialogTitle className="mt-4 text-center text-[24px] font-bold leading-tight">
              {mode === "in" ? "Oturum Aç" : "Hesap Oluştur"}
            </DialogTitle>
            <DialogDescription className="mt-1 text-center text-[14px]">
              {reason ?? "AetherOS Mağazası için Proton Mail hesabınızı kullanın."}
            </DialogDescription>

            <div className="mt-5 grid grid-cols-2 rounded-lg bg-muted p-0.5 text-sm font-medium">
              {(["in", "up"] as const).map((m) => (
                <button
                  type="button"
                  key={m}
                  onClick={() => {
                    setMode(m);
                    setError(null);
                  }}
                  className={`rounded-md py-1.5 ${mode === m ? "bg-card shadow-sm" : "text-muted-foreground"}`}
                >
                  {m === "in" ? "Giriş" : "Kayıt"}
                </button>
              ))}
            </div>

            <div className="mt-4 overflow-hidden rounded-2xl bg-muted">
              {mode === "up" && (
                <label className={`${row} border-b border-border`}>
                  <UserIcon className="h-5 w-5 shrink-0 text-muted-foreground" />
                  <input
                    className={input}
                    placeholder="Ad Soyad"
                    autoComplete="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </label>
              )}
              <label className={`${row} border-b border-border`}>
                <Mail className="h-5 w-5 shrink-0 text-muted-foreground" />
                <input
                  className={input}
                  type="email"
                  inputMode="email"
                  autoCapitalize="none"
                  autoComplete="email"
                  placeholder="ad@proton.me"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </label>
              <label className={row}>
                <span className="w-5 shrink-0 text-center text-muted-foreground">•••</span>
                <input
                  className={input}
                  type={show ? "text" : "password"}
                  autoComplete={mode === "in" ? "current-password" : "new-password"}
                  placeholder={mode === "up" ? "Şifre (en az 8 karakter)" : "Şifre"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button type="button" onClick={() => setShow((s) => !s)} aria-label="Şifreyi göster/gizle">
                  {show ? <EyeOff className="h-5 w-5 text-muted-foreground" /> : <Eye className="h-5 w-5 text-muted-foreground" />}
                </button>
              </label>
            </div>

            {(domainBad || error) && (
              <p className="mt-2 px-1 text-[13px] text-destructive" role="alert">
                {error ?? PROTON_ERROR}
              </p>
            )}

            <button
              type="submit"
              disabled={busy || !trimmed || !password || (mode === "up" && !name.trim())}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-[17px] font-semibold text-primary-foreground transition-opacity disabled:opacity-40"
            >
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}
              {mode === "in" ? "Devam" : "Hesap Oluştur"}
            </button>

            <p className="mt-4 text-center text-[12px] leading-snug text-muted-foreground">
              Yalnızca Proton Mail (@proton.me, @protonmail.com) adresleri kabul edilir. Oturum açmadan uygulama
              indirilemez.
            </p>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
