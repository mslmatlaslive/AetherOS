import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { Search as SearchIcon, X } from "lucide-react";
import { z } from "zod";
import { searchApps } from "@/lib/store.functions";
import { AppRow } from "@/components/store/AppRow";
import { getCachedSearch, normalizeQuery, setCachedSearch } from "@/lib/search-cache";

const DEBOUNCE_MS = 300;

export const Route = createFileRoute("/search")({
  validateSearch: z.object({ q: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Ara — Mağaza" },
      { name: "description", content: "Mağazadaki tüm uygulamalarda arama yapın." },
      { property: "og:title", content: "Ara — Mağaza" },
      { property: "og:description", content: "Mağazadaki tüm uygulamalarda arama yapın." },
    ],
  }),
  component: SearchPage,
});

const suggestions = ["whatsapp", "instagram", "tiktok", "oyun", "pubg", "müzik", "harita", "banka", "spor"];

function SearchPage() {
  const { q = "" } = Route.useSearch();
  const navigate = useNavigate({ from: "/search" });
  const [text, setText] = useState(q);
  const [term, setTerm] = useState(q);

  // 300ms debounce: kullanıcı yazmayı bıraktığında arama başlar.
  // Önbellekte varsa ya da alan boşaltıldıysa beklemeden anında uygulanır.
  useEffect(() => {
    const clean = text.trim();
    const apply = () => {
      setTerm(clean);
      navigate({ search: { q: clean || undefined }, replace: true });
    };
    if (!clean || getCachedSearch(clean)) {
      apply();
      return;
    }
    const t = setTimeout(apply, DEBOUNCE_MS);
    return () => clearTimeout(t);
  }, [text, navigate]);

  const fn = useServerFn(searchApps);
  const key = normalizeQuery(term);
  const { data, isFetching } = useQuery({
    queryKey: ["search", key],
    // react-query yeni anahtara geçince bir önceki isteğin signal'ini iptal eder (AbortController).
    queryFn: async ({ signal }) => {
      const cached = getCachedSearch(key);
      if (cached) return cached;
      // Değişken olarak geçilir: sürümünüz `signal` tipini bilmese bile derleme hatası vermez.
      const opts = { data: { term, offset: 0 }, signal };
      const result = await fn(opts);
      // Sunucu fonksiyonu signal'i desteklemese bile eski isteğin sonucu çöpe atılır.
      if (signal.aborted) throw new DOMException("Aborted", "AbortError");
      setCachedSearch(key, result);
      return result;
    },
    initialData: () => getCachedSearch(key),
    placeholderData: keepPreviousData,
    staleTime: 300_000,
    enabled: key.length > 0,
  });

  return (
    <div className="px-5 pt-12">
      <h1 className="text-[34px] font-bold">Ara</h1>
      <div className="mt-2 flex items-center gap-2 rounded-xl bg-muted px-3 py-2">
        <SearchIcon className="h-4 w-4 text-muted-foreground" />
        <input
          autoFocus
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Oyunlar, Uygulamalar ve Daha Fazlası"
          className="flex-1 bg-transparent text-[17px] outline-none placeholder:text-muted-foreground"
        />
        {text && (
          <button onClick={() => setText("")} aria-label="Temizle">
            <X className="h-4 w-4 rounded-full bg-muted-foreground p-0.5 text-muted" />
          </button>
        )}
      </div>

      {!term && (
        <section className="mt-6">
          <h2 className="text-[22px] font-bold">Keşfet</h2>
          {suggestions.map((s) => (
            <button key={s} onClick={() => setText(s)} className="block w-full border-b border-border py-3 text-left text-[20px] text-primary">
              {s}
            </button>
          ))}
        </section>
      )}

      {term && isFetching && <p className="mt-10 text-center text-muted-foreground">Aranıyor…</p>}
      {term && data && data.length === 0 && <p className="mt-10 text-center text-muted-foreground">Sonuç bulunamadı</p>}
      <div className="mt-2">{term && data?.map((a) => <AppRow key={a.id} app={a} />)}</div>
    </div>
  );
}
