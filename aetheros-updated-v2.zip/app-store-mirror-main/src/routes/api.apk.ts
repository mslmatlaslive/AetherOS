import { createFileRoute } from "@tanstack/react-router";

/**
 * APK indirme vekil sunucusu (tarayıcı sürümü için).
 * Aptoide CDN'i CORS başlığı vermediğinden, ilerleme çubuğunun çalışabilmesi için dosya
 * aynı kökenden akıtılır. Açık vekil (SSRF) olmaması için yalnızca *.aptoide.com'a izin verilir.
 */
const ALLOWED = /(^|\.)aptoide\.com$/i;

function check(raw: string | null): URL | null {
  if (!raw) return null;
  try {
    const u = new URL(raw);
    if (u.protocol === "http:") u.protocol = "https:";
    if (u.protocol !== "https:" || !ALLOWED.test(u.hostname)) return null;
    return u;
  } catch {
    return null;
  }
}

export const Route = createFileRoute("/api/apk")({
  server: {
    handlers: {
      GET: async ({ request }: { request: Request }) => {
        let target = check(new URL(request.url).searchParams.get("url"));
        if (!target) return new Response("Geçersiz adres", { status: 400 });

        // Yönlendirmeleri elle takip et; her adım izinli alan adında kalmalı.
        let upstream: Response | null = null;
        for (let hop = 0; hop < 4 && target; hop++) {
          upstream = await fetch(target, { redirect: "manual" });
          const loc = upstream.headers.get("location");
          if (upstream.status >= 300 && upstream.status < 400 && loc) {
            target = check(new URL(loc, target).toString());
            upstream = null;
            continue;
          }
          break;
        }
        if (!upstream || !upstream.ok || !upstream.body) return new Response("İndirilemedi", { status: 502 });

        const headers = new Headers({
          "content-type": "application/vnd.android.package-archive",
          "cache-control": "no-store",
        });
        const len = upstream.headers.get("content-length");
        if (len) headers.set("content-length", len);
        return new Response(upstream.body, { status: 200, headers });
      },
    },
  },
});
