import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { GAME_CATEGORIES, getGames, type AppSummary } from "@/lib/store.functions";
import { AppIcon, AppRow, GetButton, formatCount } from "@/components/store/AppRow";
import { DownloadBar } from "@/components/store/DownloadProgress";
import { useAuth } from "@/lib/auth";
import { usePinnedApps } from "@/components/store/PinnedApps";

export const Route = createFileRoute("/games")({
  head: () => ({
    meta: [
      { title: "Oyunlar — AetherOS" },
      { name: "description", content: "Öne çıkan oyunlar, popüler içerikler ve kategoriler." },
      { property: "og:title", content: "Oyunlar — AetherOS" },
      { property: "og:description", content: "Öne çıkan oyunlar, popüler içerikler ve kategoriler." },
    ],
  }),
  component: Games,
});

type Section = "featured" | "popular" | "new" | "category";

function useGames(section: Section, limit: number, category?: string) {
  const fn = useServerFn(getGames);
  return useQuery({
    queryKey: ["games", section, category ?? "", limit],
    queryFn: () => fn({ data: { section, category, limit } }),
    staleTime: 600_000,
  });
}

const gradients = [
  "from-indigo-600 via-purple-600 to-pink-500",
  "from-emerald-500 via-teal-600 to-cyan-600",
  "from-orange-500 via-rose-500 to-fuchsia-600",
  "from-sky-500 via-blue-600 to-violet-700",
];

function useOpenApp() {
  const router = useRouter();
  const { user, openAuth } = useAuth();
  return (id: string) => {
    if (!user) {
      openAuth({ reason: "Oyun sayfalarını görmek için Proton Mail hesabınızla oturum açın." });
      return;
    }
    void router.navigate({ to: "/app/$id", params: { id } });
  };
}

function Games() {
  const openApp = useOpenApp();
  const featured = useGames("featured", 6);
  const pinned = usePinnedApps();
  const pinnedIds = new Set((pinned.data ?? []).map((p) => p.id));
  const featuredList = [...(pinned.data ?? []), ...(featured.data ?? []).filter((g) => !pinnedIds.has(g.id))];
  const popular = useGames("popular", 12);
  const fresh = useGames("new", 9);
  const [cat, setCat] = useState<string>(GAME_CATEGORIES[0].key);
  const byCat = useGames("category", 10, cat);

  const date = new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="pt-5">
      <header className="px-5">
        <p className="text-[13px] font-semibold uppercase tracking-wide text-muted-foreground">{date}</p>
        <h1 className="text-[36px] font-extrabold leading-tight tracking-tight">Oyunlar</h1>
      </header>

      {/* Öne çıkan oyunlar: büyük kartlar, yatay kaydırma */}
      <section className="mt-4">
        {featured.isLoading && pinned.isLoading && <p className="px-5 py-10 text-center text-muted-foreground">Yükleniyor…</p>}
        {featured.error && <p className="px-5 py-10 text-center text-destructive">Oyunlar alınamadı.</p>}
        <div className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto px-5">
          {featuredList.map((g, i) => (
            <FeaturedCard key={g.id} game={g} index={i} pinned={pinnedIds.has(g.id)} onOpen={() => openApp(g.id)} />
          ))}
        </div>
      </section>

      {/* Popüler oyunlar: App Store'daki gibi 3'lü sütunlar */}
      <section className="mt-8">
        <SectionTitle title="Popüler Oyunlar" subtitle="Şu an en çok oynananlar" />
        <ColumnShelf apps={popular.data} loading={popular.isLoading} />
      </section>

      {/* Kategoriler */}
      <section className="mt-8">
        <SectionTitle title="Kategoriler" />
        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto px-5">
          {GAME_CATEGORIES.map((c) => (
            <button
              key={c.key}
              onClick={() => setCat(c.key)}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-[14px] font-semibold ${
                cat === c.key ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
              }`}
            >
              <span>{c.emoji}</span>
              {c.label}
            </button>
          ))}
        </div>
        <div className="mx-5 mt-3 overflow-hidden rounded-3xl bg-card px-4 shadow-[var(--shadow-card)]">
          {byCat.isLoading && <p className="py-8 text-center text-muted-foreground">Yükleniyor…</p>}
          {byCat.data?.map((a, i) => <AppRow key={a.id} app={a} rank={i + 1} />)}
        </div>
      </section>

      {/* Yeni ve dikkat çekenler */}
      <section className="mt-8">
        <SectionTitle title="Yeni ve Dikkat Çeken" subtitle="Keşfetmeye değer yeni oyunlar" />
        <ColumnShelf apps={fresh.data} loading={fresh.isLoading} />
      </section>
    </div>
  );
}

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="px-5">
      <h2 className="text-[22px] font-bold leading-tight">{title}</h2>
      {subtitle && <p className="text-[14px] text-muted-foreground">{subtitle}</p>}
    </div>
  );
}

function FeaturedCard({ game, index, pinned, onOpen }: { game: AppSummary; index: number; pinned?: boolean; onOpen: () => void }) {
  return (
    <div
      role="link"
      tabIndex={0}
      onClick={onOpen}
      onKeyDown={(e) => e.key === "Enter" && onOpen()}
      className="relative aspect-[4/5] w-[82%] max-w-[340px] shrink-0 cursor-pointer snap-center overflow-hidden rounded-3xl shadow-[var(--shadow-card)] transition-transform active:scale-[0.98]"
    >
      <img src={game.icon} alt="" className="absolute inset-0 h-full w-full scale-[3.5] object-cover blur-2xl" />
      <div className={`absolute inset-0 bg-gradient-to-br ${gradients[index % gradients.length]} opacity-60 mix-blend-multiply`} />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/30" />
      <span className="absolute left-0 top-0 rounded-br-2xl bg-black/35 px-4 py-2 text-[12px] font-bold uppercase tracking-wide text-white backdrop-blur">
        {pinned ? "Popüler" : index === 0 ? "Haftanın Oyunu" : "Öne Çıkan Oyun"}
      </span>
      <div className="absolute inset-x-0 top-[16%] flex justify-center">
        <AppIcon src={game.icon} size={120} />
      </div>
      <div className="absolute inset-x-0 bottom-0 p-4 text-white">
        <p className="text-[11px] font-bold uppercase tracking-wide text-white/80">{game.genre}</p>
        <p className="truncate text-[24px] font-bold leading-tight">{game.name}</p>
        <p className="truncate text-[14px] text-white/80">{game.developer}</p>
        <div className="mt-3 flex items-center justify-between gap-3 rounded-2xl bg-black/30 p-3 backdrop-blur">
          <p className="min-w-0 truncate text-[12px] text-white/80">{formatCount(game.downloads ?? 0)} indirme</p>
          <GetButton app={game} label="indir" overlay />
        </div>
        <DownloadBar id={game.id} className="mt-2 text-white" />
      </div>
    </div>
  );
}

/** 3'lü dikey satır grupları halinde yatay kaydırılan raf. */
function ColumnShelf({ apps, loading }: { apps?: AppSummary[]; loading: boolean }) {
  if (loading) return <p className="px-5 py-8 text-center text-muted-foreground">Yükleniyor…</p>;
  const groups: AppSummary[][] = [];
  (apps ?? []).forEach((a, i) => {
    if (i % 3 === 0) groups.push([a]);
    else groups[groups.length - 1]?.push(a);
  });
  return (
    <div className="no-scrollbar mt-1 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5">
      {groups.map((g, gi) => (
        <div key={gi} className="w-[88%] max-w-[360px] shrink-0 snap-start">
          {g.map((a) => (
            <CompactRow key={a.id} app={a} />
          ))}
        </div>
      ))}
    </div>
  );
}

function CompactRow({ app }: { app: AppSummary }) {
  const openApp = useOpenApp();
  return (
    <div className="flex items-center gap-3 py-2.5">
      <button onClick={() => openApp(app.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
        <AppIcon src={app.icon} size={60} />
        <div className="min-w-0 flex-1 border-b border-border pb-2.5">
          <p className="truncate text-[15px] font-medium">{app.name}</p>
          <p className="truncate text-[13px] text-muted-foreground">{app.genre}</p>
          <DownloadBar id={app.id} className="mt-1" />
        </div>
      </button>
      <GetButton app={app} />
    </div>
  );
}
