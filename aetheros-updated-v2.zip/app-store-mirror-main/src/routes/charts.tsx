import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { getCharts } from "@/lib/store.functions";
import { AppRow } from "@/components/store/AppRow";
import { PinnedCards, usePinnedApps } from "@/components/store/PinnedApps";

export const Route = createFileRoute("/charts")({
  head: () => ({
    meta: [
      { title: "Uygulamalar — Mağaza" },
      { name: "description", content: "En popüler ücretsiz ve ücretli uygulama sıralamaları." },
      { property: "og:title", content: "Uygulamalar — Mağaza" },
      { property: "og:description", content: "En popüler ücretsiz ve ücretli uygulama sıralamaları." },
    ],
  }),
  component: Charts,
});

function Charts() {
  const [kind, setKind] = useState<"top-free" | "top-paid">("top-free");
  const pinned = usePinnedApps();
  const fn = useServerFn(getCharts);
  const { data, isLoading } = useQuery({
    queryKey: ["charts", kind, 100],
    queryFn: () => fn({ data: { kind, limit: 100, offset: 0 } }),
    staleTime: 600_000,
  });

  return (
    <div className="px-5 pt-12">
      <h1 className="text-[34px] font-bold">Uygulamalar</h1>
      <section className="-mx-5 mt-4">
        <h2 className="px-5 pb-3 text-[22px] font-bold">Öne Çıkanlar</h2>
        <PinnedCards apps={pinned.data} />
      </section>
      <div className="mt-6 grid grid-cols-2 rounded-lg bg-muted p-0.5 text-sm font-medium">
        {(["top-free", "top-paid"] as const).map((k) => (
          <button
            key={k}
            onClick={() => setKind(k)}
            className={`rounded-md py-1.5 ${kind === k ? "bg-card shadow-sm" : "text-muted-foreground"}`}
          >
            {k === "top-free" ? "En Çok İndirilen" : "En Yeni"}
          </button>
        ))}
      </div>
      {isLoading && <p className="mt-10 text-center text-muted-foreground">Yükleniyor…</p>}
      <div className="mt-2">
        {data?.map((a, i) => <AppRow key={a.id} app={a} rank={i + 1} />)}
      </div>
    </div>
  );
}
