import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from "react";
import { useAuth } from "@/lib/auth";
import { checkInstallPermission, requestInstallPermission, startDownload, type DlTarget } from "@/lib/downloads";

type InstallCtx = {
  install: (app: DlTarget) => void;
  permissionOpen: boolean;
  answerPermission: (allow: boolean) => void;
};

const Ctx = createContext<InstallCtx | null>(null);

export function InstallProvider({ children }: { children: ReactNode }) {
  const { user, openAuth } = useAuth();
  const [permissionOpen, setPermissionOpen] = useState(false);
  const resolver = useRef<((v: boolean) => void) | null>(null);

  const askUser = useCallback(
    () =>
      new Promise<boolean>((resolve) => {
        resolver.current = resolve;
        setPermissionOpen(true);
      }),
    [],
  );

  const answerPermission = useCallback((allow: boolean) => {
    setPermissionOpen(false);
    resolver.current?.(allow);
    resolver.current = null;
  }, []);

  const installRef = useRef<(app: DlTarget) => void>(() => {});

  const install = useCallback(
    (app: DlTarget) => {
      if (!user) {
        openAuth({
          reason: "İndirmek için Proton Mail hesabınızla oturum açın.",
          // Girişten sonra kullanıcı arayüzü güncellenmiş install ile devam eder.
          onSuccess: () => installRef.current(app),
        });
        return;
      }
      void (async () => {
        let granted = await checkInstallPermission();
        if (!granted) {
          // Bir defaya mahsus izin: verildikten sonra bir daha sorulmaz.
          if (!(await askUser())) return;
          granted = await requestInstallPermission();
          if (!granted) return;
        }
        await startDownload(app);
      })();
    },
    [user, openAuth, askUser],
  );

  installRef.current = install;

  const value = useMemo(() => ({ install, permissionOpen, answerPermission }), [install, permissionOpen, answerPermission]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useInstall() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useInstall must be used inside <InstallProvider>");
  return v;
}
